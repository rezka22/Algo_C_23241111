public class Main {
    public static void main(String[] args) {
        // Membuat Aplikasi Biodata
        // Deklarasi Variable Dan Tipe Data
        String nama;
        String nim;
        String prodi;
        String tgl_lahir;
        float tinggi_badan;
        double berat_badan;
        boolean status_mahasiswa ; // jika menikah = true, belum = false 

         // Deklarasi Variable Dan Tipe Data
        nama = "rezka askananda";
        nim = "23241111";
        prodi = "Pendidikan Teknologi Informasi";
        tgl_lahir = "22 agustus 2004";
        tinggi_badan = 177.5f;
        berat_badan = 55.7d;
        status_mahasiswa = true;

        //Mencetak biodata ke layar komputer
        System.out.println("====================================");
        System.out.println("nama mahasiswa : " + nama);
        System.out.println("nim : " + nim);
        System.out.println("prodi : " + prodi);
        System.out.println("tgl lahir : " + tgl_lahir);
        System.out.println("tinggi badan : " + tinggi_badan);
        System.out.println("berat badan : " + berat_badan);
        System.out.println("status mahasiswa : " + status_mahasiswa);
        System.out.println("=====================================");


    }
}
