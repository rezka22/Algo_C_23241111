import java.util.Scanner;

     public class volumebola {
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);

            System.out.print("Masukkan jari-jari bola: ");

            double jariJari = input.nextDouble();

            double volume = (4.0) * Math.PI * Math.pow(jariJari, 3);

            System.out.println("volume bola adalah: " + volume);

            input.close();
        }
     }
