import java.util.Scanner;
public class kecepatandanpercepatan {
   public static void main(String [] args){
       Scanner input = new Scanner (System.in);
       
       System.out.println ("Program Menghitung Kecepatan dan percepatan");
       System.out.println ("-------------------------------------------");
       
       System.out.println ("Masukan Nilai Awal Kecepatan (v0) : ");
       double v0 = input.nextDouble();
       
       System.out.println ("Masukan Nilai Akhir Kecepatan (v) : ");
       double v = input.nextDouble();
       
       System.out.println ("Masukan Waktu Yang Diperlukan (t) : ");
       double t = input.nextDouble();
       
       double Vavg = (v + v0) / 2;
       
       double a = (v - v0) / t;
       
       System.out.println ("Kecepatan rata-rata : " + Vavg);
       System.out.println ("Percepatan : " + a);
       
       input.close();
       
   }
}