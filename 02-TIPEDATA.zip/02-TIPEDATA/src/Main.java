public class Main {
    public static void main(String[] args) {
        System.out.println();

        // tipe data dalam java
        // integer, byte, short, long, double, float, char, boolean

        // integer (satuan)
        int i = 10; 
        System.out.println("=====INTEGER=====");
        System.out.println("nilai integer var i : " + i);
        System.out.println("nilai  Max :" + Integer.MAX_VALUE);
        System.out.println("nilai Min :" + Integer.MIN_VALUE);
        System.out.println("besar Size Integer : " + Integer.SIZE + "bit");

        // byte
        byte b = 20;
        System.out.println("=====BYTE=====");
        System.out.println("nilai byte var b : " + b);
        System.out.println("nilai  Max :" + Byte.MAX_VALUE);
        System.out.println("nilai Min :" + Byte.MIN_VALUE);
        System.out.println("besar Size byte : " + Byte.SIZE + "bit");

        // short
        short c = 30;
        System.out.println("=====SHORT=====");
        System.out.println("nilai short var c : " + c);
        System.out.println("nilai  Max :" + Short.MAX_VALUE);
        System.out.println("nilai Min :" + Short.MIN_VALUE);
        System.out.println("besar Size short : " + Short.SIZE + "bit");

        // long
        long d = 40;
        System.out.println("=====LONG=====");
        System.out.println("nilai long var d : " + d);
        System.out.println("nilai  Max :" + Long.MAX_VALUE);
        System.out.println("nilai Min :" + Long.MIN_VALUE);
        System.out.println("besar Size long : " + Long.SIZE + "bit");

        // double
        double e = 15.1d;
        System.out.println("=====DOUBLE=====");
        System.out.println("nilai double var e : " + e);
        System.out.println("nilai  Max :" + Double.MAX_VALUE);
        System.out.println("nilai Min :" + Double.MIN_VALUE);
        System.out.println("besar Size double : " + Double.SIZE + "bit");

        // float
        float f = 11.2f;
        System.out.println("=====FLOAT=====");
        System.out.println("nilai float var f : " + f);
        System.out.println("nilai  Max :" + Float.MAX_VALUE);
        System.out.println("nilai Min :" + Float.MIN_VALUE);
        System.out.println("besar Size float : " + Float.SIZE + "bit");

        // char
        char g = 'A';
        System.out.println("=====CHAR=====");
        System.out.println("nilai char var g : " + g);
        System.out.println("besar Size char : " + Character.SIZE + "bit");

        // boolean
        boolean h = true;
        System.out.println("=====BOOLEAN=====");
        System.out.println("nilai boolean var h : " + h);
        System.out.println("nilai h : " + Boolean.TRUE);
        System.out.println("nilai h : " + Boolean.FALSE);
    }
}

